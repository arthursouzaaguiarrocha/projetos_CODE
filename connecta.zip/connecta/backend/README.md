# Connecta — Agenda de contatos em PHP MVC + SQLite

Projeto PHP sem framework, organizado em MVC, com SQLite (sem precisar instalar ou configurar MySQL), jQuery/AJAX para pesquisa instantânea e interface responsiva baseada no frontend Connecta enviado.

## Requisitos
- PHP 8.1+ com extensões **PDO_SQLite** e **mbstring** habilitadas
- Apache (XAMPP recomendado)
- Internet para carregar Google Fonts e jQuery CDN

## Instalação no XAMPP
1. Extraia a pasta `connecta_mvc` em `C:\xampp\htdocs\connecta_mvc`.
2. Inicie o Apache no XAMPP. Não é necessário iniciar MySQL.
3. Confira se as extensões `pdo_sqlite` e `sqlite3` estão habilitadas no `php.ini` do XAMPP. Se alterar o arquivo, reinicie o Apache.
4. Acesse `http://localhost/connecta_mvc/public/`.
5. O banco `storage/connecta.sqlite` e as tabelas serão criados automaticamente na primeira execução. A pasta `storage` precisa ter permissão de escrita para o Apache.

## Recursos
- Landing page responsiva Connecta
- Cadastro, login e logout com sessão PHP
- Senhas com `password_hash()` / `password_verify()`
- Token CSRF em formulários de alteração
- CRUD de contatos: nome, telefone, e-mail, WhatsApp, endereço e observações
- Pesquisa dinâmica no painel com jQuery
- Isolamento dos contatos por usuário e consultas preparadas PDO
- SQLite local, sem servidor de banco de dados

## Rotas principais
- `index.php` — landing page
- `index.php?url=register` — cadastro
- `index.php?url=login` — login
- `index.php?url=contacts` — agenda protegida
- `index.php?url=contacts/form` — novo contato
- `index.php?url=contacts/form&id=1` — editar contato

## Backup
Para fazer backup, copie o arquivo `storage/connecta.sqlite` com o sistema parado ou use a ferramenta `.backup` do SQLite. Não apague esse arquivo se quiser preservar usuários e contatos.

Para produção, configure HTTPS, mensagens/logs de erro seguros, controle de tentativas de login e proteja a pasta `storage` contra acesso direto pela web.
