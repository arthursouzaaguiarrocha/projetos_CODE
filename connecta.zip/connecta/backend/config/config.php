<?php
define('APP_NAME', 'Connecta');
define('BASE_URL', '/connecta_mvc/public');
define('DB_PATH', dirname(__DIR__) . '/storage/connecta.sqlite');
