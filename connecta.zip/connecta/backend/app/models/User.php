<?php
class User {
    public function __construct(private PDO $db) {}
    public function create(string $name, string $email, string $password): bool {
        $q = $this->db->prepare('INSERT INTO users (name,email,password) VALUES (?,?,?)');
        return $q->execute([$name, mb_strtolower(trim($email)), password_hash($password, PASSWORD_DEFAULT)]);
    }
    public function byEmail(string $email): array|false {
        $q = $this->db->prepare('SELECT * FROM users WHERE email = ? LIMIT 1'); $q->execute([mb_strtolower(trim($email))]); return $q->fetch();
    }
}
