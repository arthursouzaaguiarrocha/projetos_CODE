<?php
class ContactsController extends Controller {
    private Contact $contacts;
    public function __construct() { $this->contacts = new Contact(Database::connect()); }
    public function index(): void { $this->requireLogin(); $search=trim($_GET['q']??''); $contacts=$this->contacts->all((int)$_SESSION['user_id'],$search); $this->view('contacts/index',compact('contacts','search')); }
    public function form(): void {
        $this->requireLogin(); $id=isset($_GET['id'])?(int)$_GET['id']:null; $contact=$id?$this->contacts->find($id,(int)$_SESSION['user_id']):false;
        if ($id && !$contact) { http_response_code(404); exit('Contato não encontrado.'); }
        $error='';
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            if (!csrf_valid($_POST['csrf']??'')) $error='Sessão expirada. Atualize a página.';
            else { $v=[]; foreach(['name','phone','email','whatsapp','address','notes'] as $k) $v[$k]=trim($_POST[$k]??'');
                if ($v['name']==='' || $v['phone']==='') $error='Nome e telefone são obrigatórios.';
                elseif ($v['email']!=='' && !filter_var($v['email'],FILTER_VALIDATE_EMAIL)) $error='Informe um e-mail válido.';
                else { $this->contacts->save($v,(int)$_SESSION['user_id'],$id); $this->redirect('contacts'); }
            }
            $contact=$v;
        }
        $this->view('contacts/form',compact('contact','id','error'));
    }
    public function delete(): void { $this->requireLogin(); if ($_SERVER['REQUEST_METHOD']==='POST' && csrf_valid($_POST['csrf']??'')) $this->contacts->delete((int)($_POST['id']??0),(int)$_SESSION['user_id']); $this->redirect('contacts'); }
}
