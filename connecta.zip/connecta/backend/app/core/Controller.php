<?php
class Controller
{
    protected function view(string $name, array $data = []): void
    {
        extract($data);
        require __DIR__ . '/../views/' . $name . '.php';
    }
    protected function redirect(string $path): never
    {
        header('Location: ' . BASE_URL . '/index.php?url=' . $path);
        exit;
    }
    protected function requireLogin(): void
    {
        if (empty($_SESSION['user_id'])) $this->redirect('login');
    }
    protected function e(?string $value): string
    {
        return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
    }
}
