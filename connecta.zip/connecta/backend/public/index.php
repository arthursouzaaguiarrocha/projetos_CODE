<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/core/Controller.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Contact.php';
require_once __DIR__ . '/../app/controllers/HomeController.php';
require_once __DIR__ . '/../app/controllers/AuthController.php';
require_once __DIR__ . '/../app/controllers/ContactsController.php';
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_valid(string $token): bool
{
    return isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $token);
}
$url = trim($_GET['url'] ?? '', '/');
try {
    switch ($url) {
        case '':
            (new HomeController())->index();
            break;
        case 'login':
            (new AuthController())->login();
            break;
        case 'register':
            (new AuthController())->register();
            break;
        case 'logout':
            (new AuthController())->logout();
            break;
        case 'contacts':
            (new ContactsController())->index();
            break;
        case 'contacts/form':
            (new ContactsController())->form();
            break;
        case 'contacts/delete':
            (new ContactsController())->delete();
            break;
        default:
            http_response_code(404);
            echo 'Página não encontrada.';
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo '<h1>Erro de conexão</h1><p>Confira as configurações do banco em <code>config/config.php</code> e importe <code>database/connecta.sql</code>.</p>';
}
