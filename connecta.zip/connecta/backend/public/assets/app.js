$(function () {
  $('.mobile-menu').on('click', function () { $('.topbar nav').toggleClass('nav-open'); });
  $('#contact-search').on('input', function () { var term = $.trim($(this).val().toLowerCase()), shown = 0; $('#contacts-body tr').each(function () { var match = $(this).attr('data-search').indexOf(term) !== -1; $(this).toggle(match); if (match) shown++; }); $('#no-results').prop('hidden', shown !== 0); });
  $('.delete-form').on('submit', function (e) { if (!window.confirm('Tem certeza que deseja excluir este contato?')) e.preventDefault(); });
});
